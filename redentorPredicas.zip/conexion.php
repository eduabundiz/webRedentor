<?php 
    $host = "localhost";
    $usuario = "id13130049_gdl";
    $contrasena = "P]=QPtqM=07^DsAg";
    $bd= "id13130049_redentor";


?>